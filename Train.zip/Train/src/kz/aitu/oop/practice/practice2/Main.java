package kz.aitu.oop.practice.practice2;

import java.sql.*;

abstract class Train {
    abstract int getTrainCapacity();

    abstract String getType();
}

class Luxe extends Train {
    private int trainCapacity = 12;

    @Override
    public int getTrainCapacity() {
        return this.trainCapacity;
    }
    @Override
    public String getType(){
        return "Luxe";
    }
}

class Coupe extends Train {
    private final int trainCapacity = 20;
    @Override
    public int getTrainCapacity() {
        return this.trainCapacity;
    }
    public String getType(){
        return "Coupe";
    }
}

class Couchette extends Train {
    private final int trainCapacity = 50;
    public int getTrainCapacity() {
        return this.trainCapacity;
    }
    public String getType(){
        return "Couchette";
    }
}

class Coach extends Train {
    private final int trainCapacity = 40;
    @Override
    public int getTrainCapacity() {
        return this.trainCapacity;
    }
    public String getType(){
        return "Coach";
    }
}

class DisabledSeat extends Train {
    private final int trainCapacity = 5;

    public String getType() {
        return "DiasbledSeat";
    }
    @Override
    public int getTrainCapacity() {
        return this.trainCapacity;
    }
}

class Passenger {
    private final Train train;
    private final int id;
    private final int age;
    private final String name;
    private final boolean disability;

    Passenger(Train train, int id, int age, String name, boolean disability) {
        this.train = train;
        this.id = id;
        this.age = age;
        this.name = name;
        this.disability = disability;
    }

}
public class Main {
    public static void main(String[] args) throws SQLException{

        SQL trainTable = new SQL();
        trainTable.sqlConnection();
        trainTable.createTable();

        Menu menu = new Menu();
        menu.printMenu();

    }
}