//package kz.aitu.oop.practice.practice2;
//
//import java.sql.*;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//import java.sql.Statement;
//
//public class Database {
//    private final String connectionURL = "jdbc:postgresql://localhost/postgres";
//    private final String user = "postgres";
//    private final String password = "aituoop";
//
//    public static final String createTable = "CREATE TABLE IF NOT EXISTS passengers " +
//            "(train VARCHAR(20), " +
//            "id INT," +
//            "age INT, " +
//            "name VARCHAR(20), " +
//            "disability BOOLEAN)";
//
//    public void createTable() throws SQLException {
//
//        System.out.println(createTable);
//
//        try (Connection connection = DriverManager.getConnection(connectionURL, user, password);
//
//             Statement statement = connection.createStatement();) {
//            statement.execute(createTable);
//        } catch (SQLException e) {
//
//            printSQLException(e);
//        }
//    }
//
//    private static final String INSERT_USERS_SQL = "INSERT INTO passengers" +
//            "  (train, id, age, name, disability) VALUES " +
//            " (?, ?, ?, ?, ?);";
//
//    public void insertRecord(String train, int id, int age, String name, Boolean isDisabled) throws SQLException {
//        DisabledSeat disabledSeats = new DisabledSeat();
//        System.out.println(INSERT_USERS_SQL);
//        try (Connection connection = DriverManager.getConnection(connectionURL, user, password);
//             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
//            preparedStatement.setString(1,train );
//            preparedStatement.setInt(2, id);
//            preparedStatement.setInt(3, age);
//            preparedStatement.setString(4, name);
//            preparedStatement.setBoolean(5, isDisabled);
//
//            System.out.println(preparedStatement);
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//
//            printSQLException(e);
//        }
//
//    }
//
//    private static final String UPDATE_USERS_SQL = "update passengers set name = ? where id = ?;";
//
//    public void updateRecord() throws SQLException {
//        System.out.println(UPDATE_USERS_SQL);
//        try (Connection connection = DriverManager.getConnection(connectionURL, user, password);
//
//             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_USERS_SQL)) {
//            preparedStatement.setString(1, "Ram");
//
//
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//
//            printSQLException(e);
//        }
//    }
//
//    private static final String DELETE_USERS_SQL = "delete from passengers;";
//    public void deleteRecord() throws SQLException {
//        System.out.println(DELETE_USERS_SQL);
//
//        try (Connection connection = DriverManager.getConnection(connectionURL, user, password);
//
//
//             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_USERS_SQL);) {
//
//            int result = preparedStatement.executeUpdate();
//            System.out.println("Number of records affected :: " + result);
//        } catch (SQLException e) {
//
//            printSQLException(e);
//        }
//
//    }
////    private void printSQLException(SQLException ex) {
////        for (Throwable e: ex) {
////            if (e instanceof SQLException) {
////                e.printStackTrace(System.err);
////                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
////                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
////                System.err.println("Message: " + e.getMessage());
////                Throwable t = ex.getCause();
////                while (t != null) {
////                    System.out.println("Cause: " + t);
////                    t = t.getCause();
////                }
////            }
////        }
//    }
//
//}
