package kz.aitu.oop.practice.practice2;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
public class SQL {
    private final String connectionURL = "jdbc:postgresql://localhost/postgres";
    private final String user = "postgres";
    private final String password = "aituoop";

    public void sqlConnection(){
        try {
            Connection connection = DriverManager.getConnection(connectionURL, user, password);
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public void createTable() throws SQLException{
        String sqlTable = "CREATE TABLE IF NOT EXISTS trainpassengers " +
                "(train VARCHAR(20), " +
                "id INT," +
                "name VARCHAR(20), " +
                "age INT, " +
                "disability BOOLEAN)";

        try (Connection connection = DriverManager.getConnection(connectionURL, user, password);

             Statement statement = connection.createStatement();) {
            statement.execute(sqlTable);
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public void insertTable(String train, int id, String name, int age, Boolean isDisabled) throws SQLException{
        String insertData = "INSERT INTO trainpassengers" +
                "  (train, id, name, age, disability) VALUES " +
                " (?, ?, ?, ?, ?);";
        try (Connection connection = DriverManager.getConnection(connectionURL, user, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertData)) {
            preparedStatement.setString(1,train );
            preparedStatement.setInt(2, id);
            preparedStatement.setString(3, name);
            preparedStatement.setInt(4, age);
            preparedStatement.setBoolean(5, isDisabled);

            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {

            printSQLException(e);
        }
    }

    public void updateNameTable(int id, String name) throws SQLException {
        String updateData = "update trainpassengers set name = ? where id = ?;";
        try (Connection connection = DriverManager.getConnection(connectionURL, user, password);

             PreparedStatement preparedStatement = connection.prepareStatement(updateData)) {
            preparedStatement.setString(id, name);


            preparedStatement.executeUpdate();
        } catch (SQLException e) {

            printSQLException(e);
        }
    }
    public void updateAgeTable(int id, int age) throws SQLException {
        String updateData = "update trainpassengers set age = ? where id = ?;";
        try (Connection connection = DriverManager.getConnection(connectionURL, user, password);

             PreparedStatement preparedStatement = connection.prepareStatement(updateData)) {
            preparedStatement.setInt(id, age);


            preparedStatement.executeUpdate();
        } catch (SQLException e) {

            printSQLException(e);
        }
    }


    public void deleteTable() throws SQLException {
        String deleteData = "delete from trainpassengers;";
        try (Connection connection = DriverManager.getConnection(connectionURL, user, password);

             PreparedStatement preparedStatement = connection.prepareStatement(deleteData);) {

            int result = preparedStatement.executeUpdate();
            System.out.println("Number of records affected :: " + result);
        } catch (SQLException e) {

            printSQLException(e);
        }
    }

    public void printTable(){
        String printData = "select * from trainpassengers;";
        try (Connection connection = DriverManager.getConnection(connectionURL, user, password);

             PreparedStatement preparedStatement = connection.prepareStatement(printData);) {
            System.out.println(printData);
        } catch (SQLException e) {

            printSQLException(e);
        }
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
