package kz.aitu.oop.practice.practice2;
import java.sql.SQLException;
import java.util.Scanner;
public class Menu{
    SQL trainTable = new SQL();
    Scanner scanner = new Scanner(System.in);
    Luxe luxe = new Luxe();
    Coach coach = new Coach();
    Coupe coupe = new Coupe();
    Couchette couchette = new Couchette();
    DisabledSeat disabledSeat = new DisabledSeat();
    public void printMenu() throws SQLException {
        System.out.println("1 - Insert data. 2 - Update data. 3 - Delete data. 4 - Print data.");

        System.out.println("Enter your command: ");
        int command = scanner.nextInt();
        commandChecker(command);
    }
    private void commandChecker(int command) throws SQLException {
        if(command == 1){
            insertDataMenu();
        }else if(command == 2){
            updateDataMenu();
        }else if(command == 3){
            deleteDataMenu();
        }else if(command == 4){
            printDataMenu();
        }else{
            System.out.println("Wrong command. Try again.");
            printMenu();
        }
    }

    private void insertDataMenu() throws SQLException {
        System.out.println("Enter train type. (1 - Coach, 2 - Couchette, 3 - Coupe, 4 - DisableSeat, 5 - Luxe): ");
        int trainType = scanner.nextInt();
        String trainTypeString = "No train";
        if(trainType == 1){
            trainTypeString = coach.getType();
        }else if(trainType == 2){
            trainTypeString = couchette.getType();
        }else if(trainType == 3){
            trainTypeString = coupe.getType();
        }else if(trainType == 4){
            trainTypeString = disabledSeat.getType();
        }else if(trainType == 5){
            trainTypeString = luxe.getType();
        }else{
            System.out.println("Wrong train. Try again.");
            insertDataMenu();
        }

        System.out.println("Insert id: ");
        int id = scanner.nextInt();
        System.out.println("Insert name: ");
        String name = scanner.nextLine();
        System.out.println("Insert age: ");
        int age = scanner.nextInt();
        System.out.println("Is passenger disability?(1 - Yes. 0 - No): ");
        boolean isDisability = scanner.nextBoolean();


        trainTable.insertTable(trainTypeString, id, name, age, isDisability);
        printMenu();
    }

    private void updateDataMenu() throws SQLException{
        System.out.println("What do you want to update?(1 - name, 2 - age.): ");
        int updateType = scanner.nextInt();
        if(updateType == 1){
            System.out.println("Enter the ID of the name you want to update: ");
            int id = scanner.nextInt();
            System.out.println("Enter updated name: ");
            String name = scanner.nextLine();
            trainTable.updateNameTable(id, name);
        }else if(updateType == 2){
            System.out.println("Enter the ID of the age you want to update: ");
            int id = scanner.nextInt();
            System.out.println("Enter updated age: ");
            int age = scanner.nextInt();
            trainTable.updateAgeTable(id, age);
        }else{
            System.out.println("Wrong train. Try again.");
            updateDataMenu();
        }
        printMenu();
    }
    private void deleteDataMenu() throws SQLException{
        trainTable.deleteTable();
        printMenu();
    }

    private void printDataMenu() throws SQLException{
        trainTable.printTable();
        printMenu();
    }
}
